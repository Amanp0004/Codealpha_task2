# Simple E-commerce Store

A basic e-commerce website built with Django (Python) for the backend and HTML/CSS/JavaScript for the frontend.

## Features

- Product listings
- Product details page
- Shopping cart
- User registration and login
- Order processing
- Order history

## Setup Instructions

1. Clone the repository:
   ```
   git clone <repository-url>
   cd ecommerce_store
   ```

2. Create a virtual environment:
   ```
   python -m venv .venv
   ```

3. Activate the virtual environment:
   - On Windows: `.venv\Scripts\activate`
   - On macOS/Linux: `source .venv/bin/activate`

4. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

5. Run migrations:
   ```
   python manage.py migrate
   ```

6. Create a superuser (optional, for admin access):
   ```
   python manage.py createsuperuser
   ```

7. Run the development server:
   ```
   python manage.py runserver
   ```

8. Open your browser and go to `http://127.0.0.1:8000/`

## Usage

- Browse products on the homepage.
- Click on a product to view details.
- Register or login to add items to cart.
- View cart and proceed to checkout.
- View order history after placing orders.

## Database

Uses SQLite for simplicity. Products, users, carts, and orders are stored in the database.

## Technologies Used

- Backend: Django (Python)
- Frontend: HTML, CSS, JavaScript
- Database: SQLite

## Contributing

Feel free to fork and contribute!

## License

This project is open source.