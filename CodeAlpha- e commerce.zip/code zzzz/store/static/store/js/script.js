// Basic JavaScript for e-commerce store
console.log('E-commerce store loaded');